#include <main.h>
#define LCD_ENABLE_PIN  PIN_B0                        
#define LCD_RS_PIN PIN_B1  
#define LCD_RW_PIN PIN_B2 
#define LCD_DATA4 PIN_B4 
#define LCD_DATA5 PIN_B5 
#define LCD_DATA6 PIN_B6 
#define LCD_DATA7 PIN_B7 
#include <lcd.c>

//
#include "_inc\types.h"
#define DS1820_DATAPIN  PIN_D0
#include "_lib\ds1820.h"

void main()
{
   lcd_init ();
   lcd_putc ("\fmcu.pinpeo.com\r\n DS1820 Demo ! ");
   int16 temperature_raw; /*Du lieu nhiet do (resolution 1 / 256°C) */
   float temperature_float; /* Gia tri nhiet do do duoc */
   char temperature[8];  /* Mang luu gia tri nhiet do*/
   unsigned int8 sensor_count;
   delay_ms(1000);

  fprintf(UART, "\n\r*** DS1820 Loading...! ***\n\r"); 
delay_ms(500);
sensor_count = 0;

   while (TRUE)
   {
     if ( DS1820_FindFirstDevice() )
        {
            do
            {
               
                temperature_raw = DS1820_GetTempRaw();
                DS1820_GetTempString(temperature_raw, temperature);
                temperature_float = DS1820_GetTempFloat();
             fprintf(UART, "Sensor %d: %f°C \n\r",
                       sensor_count,
                       temperature_float);
                  sensor_count ++;
            }
            while ( DS1820_FindNextDevice() );

            sensor_count = 0;
        }
        delay_ms(1000);
   }
}


